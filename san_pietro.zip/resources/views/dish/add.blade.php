<x-layout>
    <x-slot name="title">
        Il San Pietro | Aggiungi Piatto
    </x-slot>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <livewire:add-dish />
            </div>
        </div>
    </div>
</x-layout>
