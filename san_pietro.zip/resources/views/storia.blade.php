<x-layout>
  <x-slot name="title">
        Il San Pietro | Dove Siamo
  </x-slot>
  <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mt-5 bebas-neue-regular">La nostra Storia</h1>
            </div>
        </div>
  </div>
</x-layout>