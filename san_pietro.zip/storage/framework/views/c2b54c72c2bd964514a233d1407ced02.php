<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title', null, []); ?> 
      Il San Pietro | Home
   <?php $__env->endSlot(); ?>
  <?php if (isset($component)) { $__componentOriginalbb0b202a97205d6a822db036f9195f3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0b202a97205d6a822db036f9195f3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.masthead','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('masthead'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0b202a97205d6a822db036f9195f3f)): ?>
<?php $attributes = $__attributesOriginalbb0b202a97205d6a822db036f9195f3f; ?>
<?php unset($__attributesOriginalbb0b202a97205d6a822db036f9195f3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0b202a97205d6a822db036f9195f3f)): ?>
<?php $component = $__componentOriginalbb0b202a97205d6a822db036f9195f3f; ?>
<?php unset($__componentOriginalbb0b202a97205d6a822db036f9195f3f); ?>
<?php endif; ?>
  <div class="spaceCustom"></div>
    <div class="container mt-2">
        <h3 class="text-center mb-4 fs-1 bebas-neue-regular">i Nostri Piatti</h3>
        <div id="carouselExampleIndicators" class="carousel slide mt-2" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?php echo e(asset('images/piatto1.jpg')); ?>" class="d-block w-100" alt="..." style="height: 300px; object-fit: cover;">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('images/piatto2.jpg')); ?>" class="d-block w-100" alt="..." style="height: 300px; object-fit: cover;">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('images/piatto3.jpg')); ?>" class="d-block w-100" alt="..." style="height: 300px; object-fit: cover;">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('images/piatto4.jpg')); ?>" class="d-block w-100" alt="..." style="height: 300px; object-fit: cover;">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        <div class="d-flex justify-content-center mt-4">
            <a href="<?php echo e(route('dishes.show')); ?>" class="fs-1 mt-2 btn-xl text-dark btn-light mx-auto bebas-neue-regular">Vai al Menu</a>
        </div>   
    </div>
    </div>
    <div class="container mt-4">
        <div class="card mt-3 position-relative"> 
            <img src="http://picsum.photos/200" class="card-img-top" alt="Card Image"style="height: 300px; object-fit: cover;">
            <div class="card-img-overlay d-flex flex-column justify-content-center"> <!-- Utilizza flexbox per centrare verticalmente il contenuto -->
                <h5 class="fs-2 card-title text-center text-dark bebas-neue-regular bg-light">I nostri prodotti</h5>
                <a href="<?php echo e(route('prodotti')); ?>" class="fs-4 btn btn-light mx-auto bebas-neue-regular">Vai a prodotti</a> <!-- Utilizza mx-auto per centrare orizzontalmente il pulsante -->
            </div>
        </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/welcome.blade.php ENDPATH**/ ?>