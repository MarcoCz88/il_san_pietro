<div>
    <h1 class="text-center mt-2">Aggiungi un nuovo piatto al menù</h1>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div class="flex flex-row justify-center my-2 alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <form wire:submit.prevent="store">
        <?php echo csrf_field(); ?>
        <div>
            <label for="dish_name">Nome del piatto</label>
            <input wire:model="dish_name" name="dish_name" type="text" class="form-control <?php $__errorArgs = ['dish_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['dish_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
            <label for="dish_body">Descrizione</label>
            <textarea wire:model="dish_body" name="dish_body" type="text" class="form-control <?php $__errorArgs = ['dish_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['dish_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
           <input wire:model="temporary_images" type= file name="images" multiple class="form-control shadow <?php $__errorArgs = ['temporary_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Img"/>
           <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['temporary_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <p class="text-danger mt-2"><?php echo e($message); ?></p>
           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <!--[if BLOCK]><![endif]--><?php if(!empty($images)): ?>
          <div class="row">
            <div class="col-12">
                <p>Anteprima Foto</p>
                <div class="row border border-4 border-info rounded shadow py-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col my-3">
                  <div class="img-preview mx-auto shadow rounded" style="background-image: url('<?php echo e($image->temporaryUrl()); ?>')"></div>
                  <button type="button" class="btn btn-danger shadow d-block text-center mx-auto" wire:click="removeImage(<?php echo e($key); ?>)">Cancella</button>
                 </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="text-center">
            <button type="submit" class="btn btn-primary btn-lg fs-3 shadow my-3">Crea</button>
        </div>
    </form>
</div>
<?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/livewire/add-dish.blade.php ENDPATH**/ ?>