<nav class="navbar shadow navbarCustom navbar-expand-lg fixed-top bg-dark text-light">
    <div class="container justify-content-between">
        <a class="col-4 navbar-brand logoCustom text-center bebas-neue-regular" href="<?php echo e(route('home')); ?>">Il San Pietro</a>
        <?php if(Auth::check() && Auth::user()->is_revisor): ?>
        <div class="nav-item">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="prenotaCustom btn bebas-neue-regular fs-1">Logout</button>
            </form>
        </div>
        <?php else: ?>
        <a class="col-4 text-center nav-link prenotaCustom fs-1 bebas-neue-regular" href="<?php echo e(route('prenota.form')); ?>">Prenota</a>
        <?php endif; ?>
        <button class="col-4 navbar-toggler btnCustom " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fa-xl fa-solid fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center text-center bgLight" id="navbarSupportedContent">
            <ul class="navbar-nav bebas-neue-regular">
                
                <?php if(Auth::check() && Auth::user()->is_revisor): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.prenotazioni.index')); ?>">Gestione Prenotazioni</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Modifica Menù</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('dish.add')); ?>">Aggiungi piatto</a>
                    </li>
                    
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dishes.show')); ?>">Menù</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('prodotti')); ?>">Prodotti</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('storia')); ?>">Storia</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dovesiamo')); ?>">Dove Siamo</a>
                </li>
                <?php endif; ?> 
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/components/navbar.blade.php ENDPATH**/ ?>