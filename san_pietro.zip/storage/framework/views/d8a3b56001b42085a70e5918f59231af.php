<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
         Il San Pietro | Prodotti
     <?php $__env->endSlot(); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mt-5 bebas-neue-regular">I Nostri Prodotti</h1>
            </div>
        </div>
    </div>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo e(asset('images/prodotti3.jpg')); ?>" alt="" class="img-fluid mb-4">
            </div>
            <div class="col-md-6">
                <p><strong>Prodotti Freschi:</strong> Il ristorante utilizza esclusivamente ingredienti freschi e di stagione per garantire il massimo sapore e valore nutrizionale nei piatti. Gli ingredienti freschi sono spesso più gustosi e offrono una migliore esperienza culinaria.</p>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6 order-md-2">
                <img src="<?php echo e(asset('images/prodotti2.jpeg')); ?>" alt="" class="img-fluid mb-4">
            </div>
            <div class="col-md-6 order-md-1">
                <p><strong>Prodotti a Chilometro Zero:</strong> Il concetto di chilometro zero indica che gli ingredienti sono ottenuti da fornitori locali, riducendo al minimo il trasporto e l'impatto ambientale associato. Ciò promuove la sostenibilità, supporta i produttori locali e garantisce ingredienti freschi.</p>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <img src="<?php echo e(asset('images/prodotti1.jpeg')); ?>" alt="" class="img-fluid mb-4">
            </div>
            <div class="col-md-6">
                <p><strong>Alta Qualità:</strong> Il ristorante si impegna a utilizzare solo ingredienti di altissima qualità per offrire piatti deliziosi e soddisfacenti ai suoi clienti. La selezione accurata degli ingredienti è fondamentale per la creazione di piatti raffinati e gustosi.</p>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/prodotti.blade.php ENDPATH**/ ?>