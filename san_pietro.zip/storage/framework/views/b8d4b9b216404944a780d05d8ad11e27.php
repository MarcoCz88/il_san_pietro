<div class="masthead mb-5">
    <div class="container ">
        <div class="row  align-items-center">
            <div class="col-lg-12 bebas-neue-regular">
                <h2 class="display-4 text-white mt-3 mb-2 bgCustom4"><strong>Benvenuti<br> da</strong><br></h2>
                <h1 class="display-4 text-white mt-5 mb-2 bgCustom4"><em> Il San Pietro</em></h1>
                <!-- <p class="lead mt-5 mb-5 text-white bgCustom4">Scopri la nostra cucina e prenota ora!</p> -->
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/components/masthead.blade.php ENDPATH**/ ?>