<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
         Il San Pietro | Prenota
     <?php $__env->endSlot(); ?>
    <?php if(session('success')): ?>
             <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="container mt-4 bebas-neue-regular">
        <div class="row justify-content-center align-items-center"> <!-- Aggiunta align-items-center per centrare verticalmente -->
            <div class="col-md-8">
                <div class="borderCustom text-center"> <!-- Aggiunta text-center per centrare tutto il contenuto -->
                    <h1 class="mt-1 mb-2 bebas-neue-regular">Prenota il tuo tavolo</h1>
                    <div class="imgPrenotaCustom mb-2"> </div>
                    <p>Chiusi domenica sera e lunedì. La prenotazione è valida previa conferma via mail.</p>

                    <form method="POST" action="<?php echo e(route('prenota.submit')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="">
                            <label for="name" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="">
                            <label for="phone" class="form-label">Telefono</label>
                            <input type="text" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="">
                            <label for="datetime" class="form-label">Data e Ora</label>
                            <input type="datetime-local" class="form-control" id="datetime" name="datetime" required>
                        </div>
                        <div class="">
                            <label for="guests" class="form-label">Numero ospiti</label>
                            <input type="number" class="form-control" id="guests" name="guests" required>
                        </div>
                        <div class="text-center my-2">
                            <button type="submit" class="btn btnPrenotaCustom">Prenota</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\marco\OneDrive\Desktop\hack87\il_san_pietro\resources\views/prenota.blade.php ENDPATH**/ ?>